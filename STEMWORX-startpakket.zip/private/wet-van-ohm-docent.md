# Wet van Ohm — private docentuitwerking

**Niet in de GitHub Pages-publicatiemap plaatsen.** De openbare antwoordcontrole rekent lokaal; een bezoeker kan daaruit de uitkomst afleiden. Dit document bevat de begeleidende volledige uitwerking.

## Methode

Bij een vaste ohmse weerstand en gelijkblijvende omstandigheden: U = R × I; R = U / I; I = U / R. Voer I bij berekeningen in ampère in: I(A) = I(mA) / 1000. Rond pas aan na de berekening. Controleer door de drie gevonden grootheden terug in U = R × I in te vullen.

### Voorbeeld met R gevraagd

U = 9 V, I = 150 mA = 0,150 A. R = U / I = 9 / 0,150 = 60 Ω. Controle: 60 Ω × 0,150 A = 9 V.

### Voorbeeld met I gevraagd

U = 12 V, R = 60 Ω. I = U / R = 12 / 60 = 0,2 A = 200 mA. Controle: 60 Ω × 0,2 A = 12 V.

### Voorbeeld met U gevraagd

R = 40 Ω, I = 250 mA = 0,250 A. U = R × I = 40 × 0,250 = 10 V. Controle: 10 / 40 = 0,250 A.

## Generatorgrenzen en nabespreking

De generator kiest R uit 10, 20, 30, 40, 50, 60, 80, 100, 120, 150, 200 Ω en I uit 50, 100, 150, 200, 250, 300, 400, 500 mA. Alleen combinaties met 1 ≤ U ≤ 24 V en P = I²R ≤ 2 W worden gebruikt. De vermogensgrens beperkt de getallen voor oefeningen; zonder opgegeven nominale belastbaarheid van een werkelijk onderdeel is dit geen uitspraak over een veilig te bouwen schakeling. Als een leerling R = U × I toepast, vraag welke omvorming van U = R × I nodig is. Bij factor 1000 verschil: bespreek mA → A of A → mA. Een lampje is geen geschikt voorbeeld van een constante ohmse weerstand omdat de temperatuur de weerstand kan veranderen.
